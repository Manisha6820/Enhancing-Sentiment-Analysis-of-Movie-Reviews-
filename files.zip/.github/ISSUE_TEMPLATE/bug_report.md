---
name: Bug report
about: Create a report to help us improve
title: "[BUG] <short description>"
labels: bug
assignees: ''
---

**Describe the bug**
A clear and concise description of what the bug is.

**To Reproduce**
Steps to reproduce the behavior:
1. Run command: `python scripts/run_deep.py --model cnn --epochs 10`
2. Provide dataset: `data/imdb/...`
3. See error

**Expected behavior**
A clear and concise description of what you expected to happen.

**Environment (please complete the following information):**
- OS: [e.g. Ubuntu 20.04]
- Python version: [e.g. 3.8.10]
- pip freeze / requirements: (paste)
- GPU: [yes/no and model]

**Additional context**
Add any other context about the problem here (logs, stack traces, small data sample).