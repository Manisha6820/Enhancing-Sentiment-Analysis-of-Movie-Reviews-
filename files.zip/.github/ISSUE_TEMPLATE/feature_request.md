---
name: Feature request
about: Suggest an idea for this project
title: "[FEATURE] <short description>"
labels: enhancement
assignees: ''
---

**Is your feature request related to a problem? Please describe.**
A clear and concise description of the problem or use-case.

**Describe the solution you'd like**
Describe the feature and how it would improve the project.

**Describe alternatives you've considered**
Any other options you explored.

**Additional context**
Include any mockups, code samples, or references.