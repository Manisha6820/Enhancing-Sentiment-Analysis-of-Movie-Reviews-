---
name: Pull request
about: Template for pull requests
labels: ''
assignees: ''
---

## Summary
Brief explanation of the changes.

## Related issues
- Fixes # (issue number)
- Related to # (issue number)

## Changes
- File(s) added
- File(s) changed
- Tests added/updated

## How to test
Provide step-by-step instructions to verify the changes locally.

## Checklist
- [ ] Code follows style guidelines (PEP8)
- [ ] New and existing tests pass
- [ ] Documentation updated (if applicable)
- [ ] License compatibility checked

## Notes
Any special notes for reviewers.